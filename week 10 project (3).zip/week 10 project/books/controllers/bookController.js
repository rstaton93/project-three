const Book = require('../models/Book')
const bcrypt = require('bcrypt')

const getAllBooks = asyncHandler(async (req, res) => {

    const books = await Book.find().select().lean()

    if (!books?.length) {
        return res.status(400).json({ message: 'No books found' })
    }

    res.json(books)
})


const createNewBook = asyncHandler(async (req, res) => {
    const { bookname, author } = req.body

    // Confirm data
    if (!bookname || !author ) {
        return res.status(400).json({ message: 'All fields are required' })
    }
    const bookObject = { bookname, author }
    
    // Create and store new user 
    const book = await Book.create(bookObject)

    if (book) { //created 
        res.status(201).json({ message: `New book ${bookname} created` })
    } else {
        res.status(400).json({ message: 'Invalid book data received' })
    }
})

// @desc Update a user
// @route PATCH /users
// @access Private
const updateBook = asyncHandler(async (req, res) => {
    const { id, bookname} = req.body

    // Confirm data 
    if (!id || !bookname || !author) {
        return res.status(400).json({ message: 'All fields are required' })
    }

    // Does the user exist to update?
    const book = await Book.findById(id).exec()

    if (!book) {
        return res.status(400).json({ message: 'Book not found' })
    }



    book.bookname = bookname
    book.author = author



    const updatedBook = await book.save()

    res.json({ message: `${updatedBook.bookname} updated` })
})

// @desc Delete a user
// @route DELETE /users
// @access Private
const deleteBook = asyncHandler(async (req, res) => {
    const { id } = req.body

    // Confirm data
    if (!id) {
        return res.status(400).json({ message: 'Book ID Required' })
    }


    // Does the user exist to delete?
    const book = await Book.findById(id).exec()

    if (!book) {
        return res.status(400).json({ message: 'Book not found' })
    }

    const result = await book.deleteOne()

    const reply = `Bookname ${result.bookname} with ID ${result._id} deleted`

    res.json(reply)
})

module.exports = {
    getAllBooks,
    createNewBook,
    updateBook,
    deleteBook
}