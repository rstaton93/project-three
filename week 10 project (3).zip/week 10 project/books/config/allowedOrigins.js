const allowedOrigins = [
    'http://localhost:3000',
    'http://www.booksonshelf.com',
    'http://booksonshelf.com'
]

module.exports = allowedOrigins