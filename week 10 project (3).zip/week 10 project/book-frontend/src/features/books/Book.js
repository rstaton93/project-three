import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react'; // Import useEffect hook

import { useSelector } from 'react-redux';
import { selectBookById } from './booksApiSlice';

// Initialize the itemCount outside the Book component
let itemCount = 0;

const Book = ({ bookId }) => {
    const book = useSelector(state => selectBookById(state, bookId));

    const navigate = useNavigate();

    if (book) {
        const handleEdit = () => navigate(`/dash/books/${bookId}`);

        const bookAuthorString = book.author.toString().replaceAll(',', ', ');

        const cellStatus = book.active ? '' : 'table__cell--inactive';

        return (
            <tr className="table__row book">
                <td className={`table__cell ${cellStatus}`}>{book.bookname}</td>
                <td className={`table__cell ${cellStatus}`}>{bookAuthorString}</td>
            </tr>
        );
    } else return null;
};

export default Book;
