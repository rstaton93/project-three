import { Link } from 'react-router-dom'

const Public = () => {
    const content = (
        <section className="public">
            <header>
                <h1>Welcome to <span className="nowrap">The Library</span></h1>
                <Link to="/dash" className="dash-header__nav-button">Books</Link>
            </header>
            <main className="public__main">
                <p>The only Library that probably wont have the book you're looking for unless it's a little homosexual.</p>
                <address className="public__addr">
                    The Library<br />
                    1234 Query Street<br />
                    Big Yikes, CO 12345<br />
                    <a href="tel:+15555555555">(555) 555-5555</a>
                </address>
                <br />
                <p>Owner: Ronnie</p>
            </main>

        </section>

    )
    return content
}
export default Public